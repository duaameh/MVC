﻿using Microsoft.EntityFrameworkCore;
using mvc2.Models;

namespace mvc2.context
{
    public class MyContext : DbContext
    {
        public MyContext(DbContextOptions<MyContext> options) : base(options) { }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            var builder = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: true);
            IConfigurationRoot configurationRoot = builder.Build();
            var constring = configurationRoot.GetConnectionString("my connection");
            optionsBuilder.UseSqlServer(constring);


        }
        public DbSet<Productcs> Productcs { get; set; }
    }

    }
