﻿using Microsoft.AspNetCore.Mvc;
using mvc2.context;
using mvc2.Models;

namespace mvc2.Controllers
{
    public class ProductcsControllers : Controller
    {
        private readonly MyContext _myContext;
        private readonly IWebHostEnvironment environment;

        public ProductcsControllers( MyContext myContext,IWebHostEnvironment Environment)
        {
            _myContext = myContext;
            environment = Environment;
        }
        public IActionResult Index()
        {
            var Productcs=_myContext.Productcs.ToList();
            return View(Productcs);
        }
        [HttpGet]
        public IActionResult Create() 
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(ProductDto productDto)
        {
            if (productDto.ImageFile == null)
            {
                ModelState.AddModelError("ImageFile", "The image file is required");
                return View(productDto);
            }

            // Save the image file
            string newFileName = DateTime.Now.ToString("yyyyMMdd");
            newFileName += Path.GetExtension(productDto.ImageFile!.FileName);

            string imageFullPath = environment.WebRootPath + "/Product/" + newFileName;

            using (var stream = System.IO.File.Create(imageFullPath))
            {
                productDto.ImageFile.CopyTo(stream);
            }

            Productcs product = new Productcs()
            {
                Name = productDto.Name,
                Brand = productDto.Brand,
                Category = productDto.Category,
                Price = productDto.Price,
                Description = productDto.Description,
                ImageFileName = newFileName,
                CreatedAt = DateTime.Now,
            };

            _myContext.Productcs.Add(product);
            _myContext.SaveChanges();
            return RedirectToAction("Index", "ProductcsControllers");
        }
        public IActionResult Delete(int id)
        {
            var product =_myContext.Productcs.Find(id);
            if (product == null)
            {
                return RedirectToAction("Index", "ProductcsControllers");
            }

            string imageFullPath = environment.WebRootPath + "/products/" + product.ImageFileName;
            System.IO.File.Delete(imageFullPath);

            _myContext.Productcs.Remove(product);
            _myContext.SaveChanges(true);

            return RedirectToAction("Index", "ProductcsControllers");
        }





    }
}
