﻿using System.ComponentModel.DataAnnotations;

namespace task1.Models
{
    public class feedback
    {
        [Key]
        public int FeedbackId { get; set; }
        public string Email { get; set; }
        public string Message { get; set; }
    }
}
